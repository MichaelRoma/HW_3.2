//
//  ContentView.swift
//  HW_2
//
//  Created by Mykhailo Romanovskyi on 26.07.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var sliderValueRed = Double.random(in: 0...255)
    @State private var sliderValueGreen = Double.random(in: 0...255)
    @State private var sliderValueBlue = Double.random(in: 0...255)
    
    var body: some View {
        VStack {
            ColorScreenView(valueRed: $sliderValueRed,
                            valueGreen: $sliderValueGreen,
                            valueBlue: $sliderValueBlue)
            
            ColorSlider(value: $sliderValueRed, color: .red)
            ColorSlider(value: $sliderValueBlue, color: .blue)
            ColorSlider(value: $sliderValueGreen, color: .green)
            
            Spacer()
        }.padding()
            .background(Color.black)
            .edgesIgnoringSafeArea(.all)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ColorSlider: View {
    @Binding var value: Double
    var color: Color
    var body: some View {
        HStack {
            Text("0").foregroundColor(color)
            Slider(value: $value, in: 0...255, step: 1)
                .padding()
                .accentColor(color)
            Text("255").foregroundColor(color)
        }
    }
}

struct ColorScreenView: View {
    @Binding var valueRed: Double
    @Binding var valueGreen: Double
    @Binding var valueBlue: Double
    var body: some View {
        Color(red: valueRed/255, green: valueGreen/255, blue: valueBlue/255)
            .clipShape(RoundedRectangle(cornerRadius: 30))
            .frame(height: 150)
            .overlay(RoundedRectangle(cornerRadius: 30)
                .stroke(Color.green, lineWidth: 5))
    }
}
